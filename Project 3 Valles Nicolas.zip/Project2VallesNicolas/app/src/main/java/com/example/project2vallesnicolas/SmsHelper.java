package com.example.project2vallesnicolas;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.util.Log;

import androidx.core.content.ContextCompat;

/**
 * Helper class for sending SMS notifications
 */
public class SmsHelper {

    private static final String TAG = "SmsHelper";
    private static final String PREF_NAME = "WeightTrackerPrefs";
    private static final String PREF_GOAL_NOTIFICATIONS = "goal_notifications";
    private static final String PREF_MILESTONE_NOTIFICATIONS = "milestone_notifications";
    private static final String PREF_REMINDER_NOTIFICATIONS = "reminder_notifications";

    /**
     * Send a goal achievement notification via SMS
     * @param context Application context
     * @param phoneNumber Recipient phone number
     * @param goalWeight The achieved goal weight
     * @return true if SMS was sent, false otherwise
     */
    public static boolean sendGoalAchievedNotification(Context context, String phoneNumber, float goalWeight) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

        // Check if goal notifications are enabled
        if (!prefs.getBoolean(PREF_GOAL_NOTIFICATIONS, true)) {
            Log.d(TAG, "Goal notifications are disabled");
            return false;
        }

        String message = "Congratulations! You've reached your goal weight of " +
                String.format("%.1f", goalWeight) + " lbs!";

        return sendSmsMessage(context, phoneNumber, message);
    }

    /**
     * Send a milestone achievement notification via SMS
     * @param context Application context
     * @param phoneNumber Recipient phone number
     * @param milestone The achieved milestone weight
     * @return true if SMS was sent, false otherwise
     */
    public static boolean sendMilestoneNotification(Context context, String phoneNumber, float milestone) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

        // Check if milestone notifications are enabled
        if (!prefs.getBoolean(PREF_MILESTONE_NOTIFICATIONS, true)) {
            Log.d(TAG, "Milestone notifications are disabled");
            return false;
        }

        String message = "Great job! You've reached a milestone weight of " +
                String.format("%.1f", milestone) + " lbs!";

        return sendSmsMessage(context, phoneNumber, message);
    }

    /**
     * Send a weight log reminder notification via SMS
     * @param context Application context
     * @param phoneNumber Recipient phone number
     * @return true if SMS was sent, false otherwise
     */
    public static boolean sendWeightReminderNotification(Context context, String phoneNumber) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

        // Check if reminder notifications are enabled
        if (!prefs.getBoolean(PREF_REMINDER_NOTIFICATIONS, true)) {
            Log.d(TAG, "Reminder notifications are disabled");
            return false;
        }

        String message = "Reminder: Don't forget to log your weight today in your Weight Tracker app!";

        return sendSmsMessage(context, phoneNumber, message);
    }

    /**
     * Send an SMS message
     * @param context Application context
     * @param phoneNumber Recipient phone number
     * @param message Message content
     * @return true if SMS was sent, false otherwise
     */
    private static boolean sendSmsMessage(Context context, String phoneNumber, String message) {
        // Check if we have permission to send SMS
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            Log.d(TAG, "SMS permission not granted");
            return false;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Log.d(TAG, "SMS sent successfully");
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Failed to send SMS: " + e.getMessage());
            return false;
        }
    }
}