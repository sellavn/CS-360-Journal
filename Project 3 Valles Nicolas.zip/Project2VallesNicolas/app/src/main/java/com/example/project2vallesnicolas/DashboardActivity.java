package com.example.project2vallesnicolas;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Dashboard activity displays the user's current weight and progress
 */
public class DashboardActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private SharedPreferences sharedPreferences;
    private static final String PREF_NAME = "WeightTrackerPrefs";
    private static final String KEY_USER_ID = "user_id";

    private TextView textViewCurrentWeight;
    private TextView textViewLastWeighInDate;
    private Button buttonAddWeight;
    private BottomNavigationView bottomNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Get shared preferences
        sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);

        // Initialize views
        buttonAddWeight = findViewById(R.id.buttonAddWeight);
        textViewCurrentWeight = findViewById(R.id.textViewCurrentWeight);
        textViewLastWeighInDate = findViewById(R.id.textViewLastWeighInDate);
        bottomNav = findViewById(R.id.bottom_navigation);

        // Load user's weight data
        loadWeightData();

        // Set up button click listener
        buttonAddWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DashboardActivity.this, WeightDataActivity.class));
            }
        });

        // Set up bottom navigation
        bottomNav.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.navigation_dashboard) {
                // Already on dashboard
                return true;
            } else if (itemId == R.id.navigation_weight_data) {
                startActivity(new Intent(DashboardActivity.this, WeightDataActivity.class));
                return true;
            } else if (itemId == R.id.navigation_notifications) {
                startActivity(new Intent(DashboardActivity.this, NotificationSettingsActivity.class));
                return true;
            } else if (itemId == R.id.navigation_settings) {
                startActivity(new Intent(DashboardActivity.this, SettingsActivity.class));
                return true;
            }
            return false;
        });
    }

    /**
     * Refresh data when activity resumes
     */
    @Override
    protected void onResume() {
        super.onResume();

        // Reload weight data
        loadWeightData();
    }

    /**
     * Load and display the user's weight data
     */
    private void loadWeightData() {
        long userId = sharedPreferences.getLong(KEY_USER_ID, -1);

        if (userId != -1) {
            WeightEntry latestEntry = dbHelper.getLatestWeightEntry(userId);

            if (latestEntry != null) {
                // Set current weight
                textViewCurrentWeight.setText(String.format(Locale.getDefault(), "%.1f lb.", latestEntry.getWeight()));

                // Set last weigh-in date
                SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM d, yyyy", Locale.getDefault());
                String dateString = dateFormat.format(latestEntry.getDate());
                textViewLastWeighInDate.setText("Last weigh-in: " + dateString);
            } else {
                // No weight entries yet
                textViewCurrentWeight.setText("No Data");
                textViewLastWeighInDate.setText("Add your first weight entry");
            }
        }
    }
}