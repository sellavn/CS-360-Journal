package com.example.project2vallesnicolas;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * WeightDataActivity displays the user's weight entries in a grid
 * and allows adding, editing, and deleting entries
 */
public class WeightDataActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private SharedPreferences sharedPreferences;
    private static final String PREF_NAME = "WeightTrackerPrefs";
    private static final String KEY_USER_ID = "user_id";

    private LinearLayout weightEntriesContainer;
    private EditText editTextDate;
    private EditText editTextWeight;
    private EditText editTextNotes;
    private Button buttonSubmitEntry;

    private Calendar calendar;
    private SimpleDateFormat dateFormat;
    private long userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_data);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Get shared preferences
        sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        userId = sharedPreferences.getLong(KEY_USER_ID, -1);

        // Initialize views
        weightEntriesContainer = findViewById(R.id.weightEntriesContainer);
        editTextDate = findViewById(R.id.editTextDate);
        editTextWeight = findViewById(R.id.editTextWeight);
        editTextNotes = findViewById(R.id.editTextNotes);
        buttonSubmitEntry = findViewById(R.id.buttonSubmitEntry);

        // Initialize calendar and date format
        calendar = Calendar.getInstance();
        dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);

        // Set up date picker
        setupDatePicker();

        // Set up submit button
        buttonSubmitEntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addWeightEntry();
            }
        });

        // Load weight entries
        loadWeightEntries();
    }

    /**
     * Set up date picker dialog for the date input field
     */
    private void setupDatePicker() {
        // Set current date as default
        editTextDate.setText(dateFormat.format(calendar.getTime()));

        // Set up date picker dialog
        editTextDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(WeightDataActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                                calendar.set(Calendar.YEAR, year);
                                calendar.set(Calendar.MONTH, month);
                                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                                editTextDate.setText(dateFormat.format(calendar.getTime()));
                            }
                        },
                        calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
    }

    /**
     * Add a new weight entry to the database
     */
    private void addWeightEntry() {
        // Get input values
        String dateStr = editTextDate.getText().toString().trim();
        String weightStr = editTextWeight.getText().toString().trim();
        String notes = editTextNotes.getText().toString().trim();

        // Validate input
        if (TextUtils.isEmpty(dateStr)) {
            editTextDate.setError("Date is required");
            return;
        }

        if (TextUtils.isEmpty(weightStr)) {
            editTextWeight.setError("Weight is required");
            return;
        }

        try {
            // Parse date
            Date date = dateFormat.parse(dateStr);

            // Parse weight
            float weight = Float.parseFloat(weightStr);

            // Add entry to database
            long entryId = dbHelper.addWeightEntry(weight, date, notes, userId);

            if (entryId != -1) {
                // Entry added successfully
                Toast.makeText(this, "Weight entry added successfully", Toast.LENGTH_SHORT).show();

                // Clear input fields
                editTextWeight.setText("");
                editTextNotes.setText("");

                // Reset date to current date
                calendar = Calendar.getInstance();
                editTextDate.setText(dateFormat.format(calendar.getTime()));

                // Reload weight entries
                loadWeightEntries();
            } else {
                Toast.makeText(this, "Failed to add weight entry", Toast.LENGTH_SHORT).show();
            }
        } catch (ParseException e) {
            editTextDate.setError("Invalid date format");
        } catch (NumberFormatException e) {
            editTextWeight.setError("Invalid weight format");
        }
    }


    /**
     * Load weight entries from database and display them
     */
    private void loadWeightEntries() {
        if (userId == -1) {
            return;
        }

        // Clear existing entries
        weightEntriesContainer.removeAllViews();

        // Get weight entries from database
        List<WeightEntry> entries = dbHelper.getAllWeightEntries(userId);

        // Check if entries exist
        if (entries.isEmpty()) {
            // No entries, show message
            TextView emptyView = new TextView(this);
            emptyView.setText("No weight entries yet. Add your first entry below.");
            emptyView.setPadding(32, 32, 32, 32);
            weightEntriesContainer.addView(emptyView);
            return;
        }

        // Add entries to the container
        LayoutInflater inflater = getLayoutInflater();
        SimpleDateFormat displayDateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);

        for (final WeightEntry entry : entries) {
            View entryView = inflater.inflate(R.layout.item_weight_entry, weightEntriesContainer, false);

            TextView textViewDate = entryView.findViewById(R.id.textViewDate);
            TextView textViewWeight = entryView.findViewById(R.id.textViewWeight);
            ImageButton buttonDeleteEntry = entryView.findViewById(R.id.buttonDeleteEntry);

            // Set entry data
            textViewDate.setText(displayDateFormat.format(entry.getDate()));
            textViewWeight.setText(String.format(Locale.getDefault(), "%.1f lbs", entry.getWeight()));

            // Set delete button click listener
            buttonDeleteEntry.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    deleteWeightEntry(entry.getId());
                }
            });

            // Add entry view to container
            weightEntriesContainer.addView(entryView);
        }
    }

    /**
     * Delete a weight entry from the database
     */
    private void deleteWeightEntry(long entryId) {
        boolean deleted = dbHelper.deleteWeightEntry(entryId);

        if (deleted) {
            Toast.makeText(this, "Entry deleted", Toast.LENGTH_SHORT).show();
            loadWeightEntries(); // Reload entries
        } else {
            Toast.makeText(this, "Failed to delete entry", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Refresh data when activity resumes
     */
    @Override
    protected void onResume() {
        super.onResume();
        loadWeightEntries();
    }
}