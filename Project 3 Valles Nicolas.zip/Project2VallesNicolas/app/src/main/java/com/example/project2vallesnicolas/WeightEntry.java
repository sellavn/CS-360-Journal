package com.example.project2vallesnicolas;

import java.util.Date;

/**
 * Model class representing a weight entry in the database
 */
public class WeightEntry {
    private long id;
    private float weight;
    private Date date;
    private String notes;
    private long userId;

    // Default constructor
    public WeightEntry() {
    }

    // Constructor with parameters
    public WeightEntry(float weight, Date date, String notes, long userId) {
        this.weight = weight;
        this.date = date;
        this.notes = notes;
        this.userId = userId;
    }

    // Getters and setters
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public float getWeight() {
        return weight;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return "WeightEntry{" +
                "id=" + id +
                ", weight=" + weight +
                ", date=" + date +
                ", notes='" + notes + '\'' +
                ", userId=" + userId +
                '}';
    }
}