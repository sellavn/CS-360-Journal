package com.example.project2vallesnicolas;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * NotificationSettingsActivity handles SMS permission requests and notification preferences
 */
public class NotificationSettingsActivity extends AppCompatActivity {

    // Permission request code
    private static final int SMS_PERMISSION_REQUEST_CODE = 100;

    // UI Components
    private ImageView imageViewPermissionStatus;
    private TextView textViewPermissionStatus;
    private Switch switchGoalNotifications;
    private Switch switchMilestoneNotifications;
    private Switch switchReminderNotifications;
    private Button buttonRequestPermission;
    private Button buttonSaveSettings;

    // Shared Preferences
    private SharedPreferences sharedPreferences;
    private static final String PREF_NAME = "WeightTrackerPrefs";
    private static final String PREF_GOAL_NOTIFICATIONS = "goal_notifications";
    private static final String PREF_MILESTONE_NOTIFICATIONS = "milestone_notifications";
    private static final String PREF_REMINDER_NOTIFICATIONS = "reminder_notifications";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_settings);

        // Initialize shared preferences
        sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);

        // Initialize UI components
        initializeViews();

        // Check current SMS permission status
        updatePermissionStatus();

        // Load saved preferences
        loadNotificationPreferences();

        // Set up listeners
        setupListeners();
    }

    /**
     * Initialize all UI components
     */
    private void initializeViews() {
        imageViewPermissionStatus = findViewById(R.id.imageViewPermissionStatus);
        textViewPermissionStatus = findViewById(R.id.textViewPermissionStatus);
        switchGoalNotifications = findViewById(R.id.switchGoalNotifications);
        switchMilestoneNotifications = findViewById(R.id.switchMilestoneNotifications);
        switchReminderNotifications = findViewById(R.id.switchReminderNotifications);
        buttonRequestPermission = findViewById(R.id.buttonRequestPermission);
        buttonSaveSettings = findViewById(R.id.buttonSaveSettings);
    }

    /**
     * Set up button click listeners
     */
    private void setupListeners() {
        // Request permission button
        buttonRequestPermission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestSmsPermission();
            }
        });

        // Save settings button
        buttonSaveSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveNotificationPreferences();
            }
        });
    }

    /**
     * Request SMS permission from the user
     */
    private void requestSmsPermission() {
        // Check if permission is already granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            // Permission is not granted, request it
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE);
        } else {
            // Permission already granted
            Toast.makeText(this, "SMS permission already granted", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Handle permission request result
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
                updatePermissionStatus();
            } else {
                // Permission denied
                Toast.makeText(this, "SMS permission denied. Notifications will not be sent.",
                        Toast.LENGTH_LONG).show();
                updatePermissionStatus();
            }
        }
    }

    /**
     * Update the UI to reflect current permission status
     */
    private void updatePermissionStatus() {
        boolean hasPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;

        if (hasPermission) {
            // Permission granted
            imageViewPermissionStatus.setImageResource(android.R.drawable.ic_menu_call);
            imageViewPermissionStatus.setColorFilter(ContextCompat.getColor(this, R.color.success));
            textViewPermissionStatus.setText("SMS permission granted");
            buttonRequestPermission.setEnabled(false);
            buttonRequestPermission.setText("Permission Granted");
        } else {
            // Permission not granted
            imageViewPermissionStatus.setImageResource(android.R.drawable.ic_delete);
            imageViewPermissionStatus.setColorFilter(ContextCompat.getColor(this, R.color.error));
            textViewPermissionStatus.setText("SMS permission not granted");
            buttonRequestPermission.setEnabled(true);
            buttonRequestPermission.setText("Grant SMS Permission");
        }
    }

    /**
     * Load notification preferences from SharedPreferences
     */
    private void loadNotificationPreferences() {
        switchGoalNotifications.setChecked(
                sharedPreferences.getBoolean(PREF_GOAL_NOTIFICATIONS, true));
        switchMilestoneNotifications.setChecked(
                sharedPreferences.getBoolean(PREF_MILESTONE_NOTIFICATIONS, true));
        switchReminderNotifications.setChecked(
                sharedPreferences.getBoolean(PREF_REMINDER_NOTIFICATIONS, true));
    }

    /**
     * Save notification preferences to SharedPreferences
     */
    private void saveNotificationPreferences() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(PREF_GOAL_NOTIFICATIONS, switchGoalNotifications.isChecked());
        editor.putBoolean(PREF_MILESTONE_NOTIFICATIONS, switchMilestoneNotifications.isChecked());
        editor.putBoolean(PREF_REMINDER_NOTIFICATIONS, switchReminderNotifications.isChecked());
        editor.apply();

        Toast.makeText(this, "Notification settings saved", Toast.LENGTH_SHORT).show();
    }
}