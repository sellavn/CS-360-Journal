package com.example.project2vallesnicolas;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.widget.ViewFlipper;

import androidx.appcompat.app.AppCompatActivity;

/**
 * MainActivity handles user authentication (login and registration)
 */
public class MainActivity extends AppCompatActivity {

    // UI Components
    private ViewFlipper viewFlipperAuth;
    private RadioGroup radioGroupMode;
    private RadioButton radioButtonLogin;
    private RadioButton radioButtonRegister;
    private EditText editTextUsername;
    private EditText editTextPassword;
    private EditText editTextRegUsername;
    private EditText editTextEmail;
    private EditText editTextRegPassword;
    private EditText editTextConfirmPassword;
    private Button buttonLogin;
    private Button buttonRegister;

    // Database Helper
    private DatabaseHelper dbHelper;

    // Shared Preferences for storing login state
    private SharedPreferences sharedPreferences;
    private static final String PREF_NAME = "WeightTrackerPrefs";
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_IS_LOGGED_IN = "is_logged_in";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Initialize shared preferences
        sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);

        // Check if user is already logged in
        if (sharedPreferences.getBoolean(KEY_IS_LOGGED_IN, false)) {
            // User is already logged in, go to dashboard
            navigateToDashboard();
            return;
        }

        // Initialize UI components
        initializeViews();

        // Set up listeners
        setupListeners();
    }

    /**
     * Initialize all UI components
     */
    private void initializeViews() {
        viewFlipperAuth = findViewById(R.id.viewFlipperAuth);
        radioGroupMode = findViewById(R.id.radioGroupMode);
        radioButtonLogin = findViewById(R.id.radioButtonLogin);
        radioButtonRegister = findViewById(R.id.radioButtonRegister);

        // Login form views
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);

        // Registration form views
        editTextRegUsername = findViewById(R.id.editTextRegUsername);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextRegPassword = findViewById(R.id.editTextRegPassword);
        editTextConfirmPassword = findViewById(R.id.editTextConfirmPassword);
        buttonRegister = findViewById(R.id.buttonRegister);
    }

    /**
     * Set up listeners for UI interactions
     */
    private void setupListeners() {
        // Radio group listener for switching between login and registration
        radioGroupMode.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radioButtonLogin) {
                    viewFlipperAuth.setDisplayedChild(0); // Show login form
                } else {
                    viewFlipperAuth.setDisplayedChild(1); // Show registration form
                }
            }
        });

        // Login button click listener
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginUser();
            }
        });

        // Register button click listener
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });
    }

    /**
     * Handle user login process
     */
    private void loginUser() {
        // Get input values
        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        // Validate input
        if (TextUtils.isEmpty(username)) {
            editTextUsername.setError("Username is required");
            editTextUsername.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            editTextPassword.setError("Password is required");
            editTextPassword.requestFocus();
            return;
        }

        // Validate credentials against database
        long userId = dbHelper.validateUser(username, password);

        if (userId != -1) {
            // Login successful
            saveLoginState(userId, username);
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
            navigateToDashboard();
        } else {
            // Login failed
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Handle user registration process
     */
    private void registerUser() {
        // Get input values
        String username = editTextRegUsername.getText().toString().trim();
        String email = editTextEmail.getText().toString().trim();
        String password = editTextRegPassword.getText().toString().trim();
        String confirmPassword = editTextConfirmPassword.getText().toString().trim();

        // Validate input
        if (TextUtils.isEmpty(username)) {
            editTextRegUsername.setError("Username is required");
            editTextRegUsername.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(email)) {
            editTextEmail.setError("Email is required");
            editTextEmail.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            editTextRegPassword.setError("Password is required");
            editTextRegPassword.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(confirmPassword)) {
            editTextConfirmPassword.setError("Please confirm your password");
            editTextConfirmPassword.requestFocus();
            return;
        }

        if (!password.equals(confirmPassword)) {
            editTextConfirmPassword.setError("Passwords do not match");
            editTextConfirmPassword.requestFocus();
            return;
        }

        // Check if username already exists
        if (dbHelper.userExists(username)) {
            editTextRegUsername.setError("Username already exists");
            editTextRegUsername.requestFocus();
            return;
        }

        // Create new user in database
        long userId = dbHelper.addUser(username, email, password);

        if (userId != -1) {
            // Registration successful
            saveLoginState(userId, username);
            Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show();
            navigateToDashboard();
        } else {
            // Registration failed
            Toast.makeText(this, "Registration failed. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Save login state to shared preferences
     */
    private void saveLoginState(long userId, String username) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putLong(KEY_USER_ID, userId);
        editor.putString(KEY_USERNAME, username);
        editor.putBoolean(KEY_IS_LOGGED_IN, true);
        editor.apply();
    }

    /**
     * Navigate to the dashboard screen
     */
    private void navigateToDashboard() {
        Intent intent = new Intent(MainActivity.this, DashboardActivity.class);
        startActivity(intent);
        finish(); // Close login activity so user can't go back
    }
}